<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'cmsclass' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '#eL{UxEpzIwunuZAECB1}*<1r3,~C9m{05]*o}l+O*bqG ~:K_>tX.&6k7^u( t2' );
define( 'SECURE_AUTH_KEY',  'R/<YQg,{5a=_ofq)NTbJx:P`.)2vVw!.)Rg~(]{M_h$!<bi{sYNTfdt4{RP,fVUL' );
define( 'LOGGED_IN_KEY',    '6BNm=?&=AiofxW!4-J12m<)b}NJOpzb<>hx>u3vrNlc]B]E_*;km_Q.TTDMS}Xh6' );
define( 'NONCE_KEY',        'm.r>+a&H|=q[V:$Oe}QB!rG`wIeaWtPLT[bJ0n/M*ibVmF<`.g!?[[3=WGyo?6O{' );
define( 'AUTH_SALT',        'yqPtFW9BL5lHcd:mW3H!XjPb*}YF29bQ Mr}BTKaS@f6:|*^|:)%_Kypo]W4vo=*' );
define( 'SECURE_AUTH_SALT', 'W[?o;8k[J/yW$6%@2*c3L@Jd~{di-NiFODOhE~6#:/7,hVt8w9L!+jYgnDpd@mon' );
define( 'LOGGED_IN_SALT',   ',RW%:t<{&K!4TH/*~zFIzdua``8eDCOJc$zbda8J$;Kqrk0c_&}=D4C9R[C(=CU+' );
define( 'NONCE_SALT',       '@mV_pO}CC[7+BpS{1G`K(ZF]Q-P-mfvH?W^`EujFDYOZPbss;-$XwTECLliy3C^a' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
